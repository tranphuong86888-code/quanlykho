const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database(path.join(__dirname, 'xuong-giay.sqlite'));
db.pragma('journal_mode = WAL');
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    fullname TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('owner','warehouse','sales')),
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS app_data (
    id INTEGER PRIMARY KEY CHECK(id = 1),
    data_json TEXT NOT NULL,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);

const seedUsers = [
  ['chuxuong', '123456', 'Chủ xưởng', 'owner'],
  ['thukho', '123456', 'Quản lý kho', 'warehouse'],
  ['banhang', '123456', 'Nhân viên bán hàng', 'sales']
];
const addUser = db.prepare('INSERT OR IGNORE INTO users(username,password_hash,fullname,role) VALUES(?,?,?,?)');
for (const [username, password, fullname, role] of seedUsers) {
  addUser.run(username, bcrypt.hashSync(password, 10), fullname, role);
}
const emptyData = {
  materials: [], products: [], partners: [], boms: [], productionOrders: [],
  warehouseHistory: [], salesOrders: [], cashflows: [], currentRole: 'owner',
  userAccount: { username: 'chuxuong', fullname: 'Chủ xưởng' }
};
if (!db.prepare('SELECT id FROM app_data WHERE id=1').get()) {
  db.prepare('INSERT INTO app_data(id,data_json) VALUES(1,?)').run(JSON.stringify(emptyData));
}

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '5mb' }));
app.use(session({
  name: 'xuonggiay.sid',
  secret: process.env.SESSION_SECRET || 'doi-chuoi-bi-mat-nay-khi-trien-khai-thuc-te',
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: false, maxAge: 8 * 60 * 60 * 1000 }
}));
app.use(express.static(__dirname));

function requireLogin(req, res, next) {
  if (!req.session.user) return res.status(401).json({ message: 'Vui lòng đăng nhập.' });
  next();
}
function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.session.user || !roles.includes(req.session.user.role)) {
      return res.status(403).json({ message: 'Bạn không có quyền thực hiện chức năng này.' });
    }
    next();
  };
}

app.post('/api/login', (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ message: 'Nhập đầy đủ tài khoản và mật khẩu.' });
  const user = db.prepare('SELECT * FROM users WHERE username=? AND active=1').get(String(username).trim());
  if (!user || !bcrypt.compareSync(String(password), user.password_hash)) {
    return res.status(401).json({ message: 'Tên đăng nhập hoặc mật khẩu không đúng.' });
  }
  req.session.user = { id: user.id, username: user.username, fullname: user.fullname, role: user.role };
  res.json({ user: req.session.user });
});
app.get('/api/me', requireLogin, (req, res) => res.json({ user: req.session.user }));
app.post('/api/logout', requireLogin, (req, res) => req.session.destroy(() => res.json({ message: 'Đã đăng xuất.' })));

app.get('/api/data', requireLogin, (req, res) => {
  const row = db.prepare('SELECT data_json,updated_at FROM app_data WHERE id=1').get();
  res.json({ data: JSON.parse(row.data_json), updatedAt: row.updated_at, user: req.session.user });
});

// Mỗi vai trò chỉ được ghi vào đúng nhóm dữ liệu của công việc mình phụ trách.
app.put('/api/data', requireLogin, (req, res) => {
  const incoming = req.body && req.body.data;
  if (!incoming || typeof incoming !== 'object' || Array.isArray(incoming)) {
    return res.status(400).json({ message: 'Dữ liệu gửi lên không hợp lệ.' });
  }
  const row = db.prepare('SELECT data_json FROM app_data WHERE id=1').get();
  const current = JSON.parse(row.data_json);
  const role = req.session.user.role;
  const allowed = {
    owner: ['materials','products','partners','boms','productionOrders','warehouseHistory','salesOrders','cashflows','userAccount'],
    warehouse: ['materials','warehouseHistory','partners','cashflows'],
    sales: ['salesOrders','warehouseHistory','products','partners','cashflows']
  }[role];
  const changed = Object.keys(incoming).filter(key => JSON.stringify(incoming[key]) !== JSON.stringify(current[key]));
  const forbidden = changed.filter(key => !allowed.includes(key) && key !== 'currentRole');
  if (forbidden.length) {
    return res.status(403).json({ message: `Vai trò hiện tại không được sửa dữ liệu: ${forbidden.join(', ')}.` });
  }
  const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
  const isAppendOnly = (oldList, newList, predicate) => Array.isArray(oldList) && Array.isArray(newList)
    && newList.length >= oldList.length
    && oldList.every((item, index) => same(item, newList[index]))
    && newList.slice(oldList.length).every(predicate);

  if (role === 'warehouse') {
    if (changed.includes('warehouseHistory') && !isAppendOnly(current.warehouseHistory, incoming.warehouseHistory, x => ['Nhập','Xuất'].includes(x.type)))
      return res.status(403).json({ message: 'Thủ kho chỉ được thêm lịch sử nhập/xuất kho, không được sửa lịch sử cũ.' });
    if (changed.includes('cashflows') && !isAppendOnly(current.cashflows, incoming.cashflows, x => x.type === 'Chi'))
      return res.status(403).json({ message: 'Thủ kho chỉ được ghi thêm khoản chi phát sinh từ nhập kho.' });
    if (changed.includes('partners')) {
      const oldMap = new Map((current.partners || []).map(x => [x.id, x]));
      const valid = (incoming.partners || []).length === (current.partners || []).length && (incoming.partners || []).every(p => {
        const old = oldMap.get(p.id); if (!old || old.type !== 'supplier') return old && same(old, p);
        return Object.keys(old).every(k => k === 'debt' || same(old[k], p[k])) && (p.debt || 0) <= (old.debt || 0);
      });
      if (!valid) return res.status(403).json({ message: 'Thủ kho chỉ được cập nhật công nợ nhà cung cấp khi nhập kho.' });
    }
  }
  if (role === 'sales') {
    if (changed.includes('warehouseHistory') && !isAppendOnly(current.warehouseHistory, incoming.warehouseHistory, x => x.type === 'Bán'))
      return res.status(403).json({ message: 'Bán hàng chỉ được thêm lịch sử xuất kho do bán hàng.' });
    if (changed.includes('cashflows') && !isAppendOnly(current.cashflows, incoming.cashflows, x => x.type === 'Thu'))
      return res.status(403).json({ message: 'Bán hàng chỉ được ghi nhận khoản thu từ đơn bán.' });
    if (changed.includes('products')) {
      const oldMap = new Map((current.products || []).map(x => [x.id, x]));
      const valid = (incoming.products || []).length === (current.products || []).length && (incoming.products || []).every(p => {
        const old = oldMap.get(p.id); return old && Object.keys(old).every(k => k === 'stock' || same(old[k], p[k])) && Number(p.stock) <= Number(old.stock);
      });
      if (!valid) return res.status(403).json({ message: 'Bán hàng chỉ được giảm tồn kho thành phẩm khi tạo đơn bán.' });
    }
    if (changed.includes('partners')) {
      const oldMap = new Map((current.partners || []).map(x => [x.id, x]));
      const valid = (incoming.partners || []).length === (current.partners || []).length && (incoming.partners || []).every(p => {
        const old = oldMap.get(p.id); if (!old || old.type !== 'customer') return old && same(old, p);
        return Object.keys(old).every(k => k === 'debt' || same(old[k], p[k])) && (p.debt || 0) >= (old.debt || 0);
      });
      if (!valid) return res.status(403).json({ message: 'Bán hàng chỉ được cập nhật công nợ khách hàng từ đơn bán.' });
    }
    if (changed.includes('salesOrders') && !isAppendOnly(current.salesOrders, incoming.salesOrders, x => !!x.id))
      return res.status(403).json({ message: 'Bán hàng chỉ được tạo đơn mới; chỉnh sửa dữ liệu đơn cũ cần Chủ xưởng.' });
  }
  // Không nhận vai trò do trình duyệt tự gửi; vai trò luôn lấy từ phiên đăng nhập.
  const merged = { ...current };
  for (const key of allowed) if (Object.prototype.hasOwnProperty.call(incoming, key)) merged[key] = incoming[key];
  merged.currentRole = role;
  db.prepare(`UPDATE app_data SET data_json=?, updated_at=CURRENT_TIMESTAMP WHERE id=1`).run(JSON.stringify(merged));
  res.json({ message: 'Đã lưu dữ liệu vào máy chủ.', updatedAt: new Date().toISOString() });
});

// Quản lý tài khoản chỉ dành cho chủ xưởng.
app.get('/api/users', requireRole('owner'), (req, res) => {
  const users = db.prepare('SELECT id,username,fullname,role,active,created_at FROM users ORDER BY id').all();
  res.json({ users });
});
app.post('/api/users', requireRole('owner'), (req, res) => {
  const { username, password, fullname, role } = req.body || {};
  if (!username || !password || !fullname || !['owner','warehouse','sales'].includes(role)) {
    return res.status(400).json({ message: 'Vui lòng nhập đủ thông tin tài khoản và vai trò hợp lệ.' });
  }
  if (String(password).length < 6) return res.status(400).json({ message: 'Mật khẩu phải có ít nhất 6 ký tự.' });
  try {
    const result = db.prepare('INSERT INTO users(username,password_hash,fullname,role) VALUES(?,?,?,?)')
      .run(String(username).trim(), bcrypt.hashSync(String(password), 10), String(fullname).trim(), role);
    res.status(201).json({ id: result.lastInsertRowid, message: 'Đã tạo tài khoản.' });
  } catch (e) {
    if (String(e.message).includes('UNIQUE')) return res.status(409).json({ message: 'Tên đăng nhập đã tồn tại.' });
    res.status(500).json({ message: 'Không thể tạo tài khoản.' });
  }
});
app.patch('/api/users/:id/active', requireRole('owner'), (req, res) => {
  const active = req.body.active ? 1 : 0;
  if (Number(req.params.id) === req.session.user.id && !active) return res.status(400).json({ message: 'Không thể tự khóa tài khoản đang đăng nhập.' });
  const result = db.prepare('UPDATE users SET active=? WHERE id=?').run(active, req.params.id);
  if (!result.changes) return res.status(404).json({ message: 'Không tìm thấy tài khoản.' });
  res.json({ message: 'Đã cập nhật trạng thái tài khoản.' });
});

app.get('/api/health', (req, res) => res.json({ status: 'ok', service: 'Xưởng giày backend' }));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'index.html')));
app.listen(PORT, () => console.log(`Xưởng giày đang chạy tại http://localhost:${PORT}`));
