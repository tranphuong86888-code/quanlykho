# Hệ thống quản lý xưởng giày - Backend

## Công nghệ
- Node.js + Express: máy chủ và API.
- SQLite (`better-sqlite3`): lưu dữ liệu bền vững trong file `xuong-giay.sqlite`.
- bcryptjs: băm mật khẩu.
- express-session: quản lý phiên đăng nhập.

## Cài đặt và chạy
1. Cài Node.js bản LTS (18 trở lên).
2. Mở Terminal tại thư mục này.
3. Chạy `npm install`.
4. Chạy `npm start`.
5. Mở `http://localhost:3000`.

## Tài khoản demo
| Vai trò | Tên đăng nhập | Mật khẩu |
|---|---|---|
| Chủ xưởng | `chuxuong` | `123456` |
| Quản lý kho | `thukho` | `123456` |
| Bán hàng | `banhang` | `123456` |

Nên đổi mật khẩu demo trước khi dùng dữ liệu thật. Chủ xưởng có thể xem danh sách và tạo tài khoản qua API quản trị `/api/users` (yêu cầu đăng nhập Chủ xưởng).

## Quyền hạn
- Chủ xưởng: toàn quyền dữ liệu, sản xuất, BOM, báo cáo, thu chi và tài khoản.
- Quản lý kho: xem dashboard, danh mục nguyên vật liệu, nhập/xuất và tồn kho. Máy chủ chỉ cho cập nhật nguyên vật liệu, thêm lịch sử nhập/xuất, ghi khoản chi nhập kho và cập nhật công nợ nhà cung cấp theo nghiệp vụ nhập kho.
- Bán hàng: xem dashboard và lập/quản lý đơn bán. Máy chủ chỉ cho tạo đơn bán mới, giảm tồn thành phẩm do bán, thêm lịch sử xuất bán, ghi khoản thu bán hàng và cập nhật công nợ khách hàng.

## Lưu trữ
Dữ liệu được lưu trong `xuong-giay.sqlite` ngay trong thư mục dự án, không phụ thuộc localStorage. Không xóa file SQLite nếu muốn giữ dữ liệu.

## Lưu ý
Đây là bản chạy nội bộ/phục vụ bài tập. Khi đưa lên Internet cần đổi `SESSION_SECRET`, bật HTTPS, dùng session store bền vững và bổ sung quy trình đổi mật khẩu/khôi phục mật khẩu. Giao diện hiện tại dùng một số hàm JavaScript cũ; các quyền ghi dữ liệu chính được kiểm tra lại ở API máy chủ.
